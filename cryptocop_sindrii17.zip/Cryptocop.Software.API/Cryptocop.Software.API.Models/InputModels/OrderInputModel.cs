namespace Cryptocop.Software.API.Models.InputModels
{
    public class OrderInputModel
    {
        public int AddressId { get; set; }

        public int PaymentCardId { get; set; }

    }
}